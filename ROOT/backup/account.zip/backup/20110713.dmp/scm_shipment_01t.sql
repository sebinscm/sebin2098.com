CREATE DATABASE  IF NOT EXISTS `scm` /*!40100 DEFAULT CHARACTER SET euckr */;
USE `scm`;
-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: localhost    Database: scm
-- ------------------------------------------------------
-- Server version	5.0.27-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `shipment_01t`
--

DROP TABLE IF EXISTS `shipment_01t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipment_01t` (
  `INVOICE_NO` varchar(30) NOT NULL,
  `BUYER_ID` varchar(10) NOT NULL,
  `ISSUE_DATE` date NOT NULL,
  `SHIPPING_PORT` varchar(20) NOT NULL,
  `HANDOVER_DATE` date NOT NULL,
  `SHIPPING_TYPE` varchar(20) NOT NULL,
  `NOMINATED_FORWARDER` varchar(50) NOT NULL,
  `BL_FILENAME` varchar(100) default NULL,
  `IV_FILENAME` varchar(100) default NULL,
  `PL_FILENAME` varchar(100) default NULL,
  `CONFIRM_STATUS` varchar(1) NOT NULL default 'N',
  `CONFIRM_DATE` date default NULL,
  `CONFIRM_ID` varchar(10) default NULL,
  `ADMIN_COMMENTS` varchar(1000) default NULL,
  `UPDATE_DATE` date default NULL,
  `SUPPLIER_ID` varchar(6) NOT NULL,
  `CREATED_ID` varchar(10) default NULL,
  PRIMARY KEY  (`INVOICE_NO`,`BUYER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_01t`
--

LOCK TABLES `shipment_01t` WRITE;
/*!40000 ALTER TABLE `shipment_01t` DISABLE KEYS */;
INSERT INTO `shipment_01t` VALUES ('INV1234','B1001','2011-05-24','05','2011-05-23','FOB','02','B1001_BL_INV1234.jpg','B1001_IV_INV1234.jpg','B1001_PL_INV1234.jpg','N','2011-05-25','B1001',NULL,'2011-05-24','S1001','9144'),('INV20110612','B9999','2011-06-07','05','2011-06-27','FOB','02','B9999_BL_INV20110612.png','B9999_IV_INV20110612.jpg','B9999_PL_INV20110612.png','N',NULL,NULL,NULL,'2011-06-07','S1001','9144');
/*!40000 ALTER TABLE `shipment_01t` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-07-13 11:57:29
