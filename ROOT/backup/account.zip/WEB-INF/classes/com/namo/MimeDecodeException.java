package com.namo;

import java.lang.Exception;

class MimeDecodeException extends Exception
{
	public MimeDecodeException()
	{
	}

	public MimeDecodeException(String s)
	{
	}
}
